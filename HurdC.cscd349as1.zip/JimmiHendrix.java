package Lab1;

public class JimmiHendrix extends GameCharacter{
	
	public JimmiHendrix() {
		solobehav = new SetGuitarOnFire();
	}
	
	public void display() {
		System.out.println("Im Jimmi");
	}


}
