package Lab1;

import java.util.Scanner;

public class GuitarHero {
		
	
		public static void main(String[] init)
		{
			int x = 0;
			while(x != 4) {
			System.out.println("Choose your character:\n 1: Slash\n 2: Jimmi Hendrix\n 3: Angus\n 4: EXIT");
			Scanner kb = new Scanner(System.in);
			String choice = kb.nextLine();
			if(choice.equals("1"))
			{
				GameCharacter slash = new Slash();
				slash.playGuitar();
				String guitar = slash.getGuitarName();
				System.out.println("Slash slays with the " + guitar+ " & ");
				slash.playSolo();
				System.out.println("\n");
				
			}
			else if(choice.equals("2"))
			{
				GameCharacter hendi = new JimmiHendrix();
				hendi.playGuitar();
				String guitar = hendi.getGuitarName();
				System.out.println("Jimmi jams with the " + guitar+ " & ");
				hendi.playSolo();
				System.out.println("\n");
			}
			else if(choice.equals("3"))
			{
				GameCharacter angus = new Angus();
				angus.playGuitar();
				String guitar = angus.getGuitarName();
				System.out.println("Angus rocks with the " + guitar + " & ");
				angus.playSolo();
				System.out.println("\n");
			}
			else if(choice.equals("4"))
			{
				System.out.println("Rock&Roll");
				x = 4;
			}
		 }
		}
			
	}


