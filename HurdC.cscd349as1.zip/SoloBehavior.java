package Lab1;

public interface SoloBehavior {

	public void playSolo();
}
