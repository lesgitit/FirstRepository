package Lab1;

public class Angus extends GameCharacter {
	
	public Angus() {
		solobehav = new JumpOffTheStage();
	}
	
	public void display() {
		System.out.println("Im Angus");
	}


}
