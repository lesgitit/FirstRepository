package Lab1;

public class Slash extends GameCharacter{
	
	public Slash() {
		solobehav = new SmashGuitar();
	}
	
	public void display() {
		System.out.println("Im Slash");
	}

}
