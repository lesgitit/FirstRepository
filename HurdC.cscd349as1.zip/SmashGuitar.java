package Lab1;

public class SmashGuitar implements SoloBehavior{
	
	public void playSolo() {
		System.out.println("Totally SMASHED his guitar!");
	}

}
