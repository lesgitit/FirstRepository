package Lab1;

public class JumpOffTheStage implements SoloBehavior {
	
	public void playSolo() {
		System.out.println("TOTALLY JUMPED OFF THE STAGE DUDE");
	}

}
