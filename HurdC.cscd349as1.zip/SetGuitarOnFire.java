package Lab1;

public class SetGuitarOnFire implements SoloBehavior {
	
	public void playSolo() {
		System.out.println("The guitar bursts into FLAMES");
	}

}
