package Lab1;

import java.util.Scanner;

public abstract class GameCharacter  {
	
	SoloBehavior solobehav;
	private String guitarName;
	
	public GameCharacter() {
	}
	
	public void playGuitar() {
		System.out.println("Choose your guitar");
		System.out.println("1:Gibson SG\n2:Fender Telecaster \n3:Gibson Flying V");
		Scanner kb = new Scanner(System.in);
		String choice = kb.nextLine(); 
		if(choice.equals("1"))
		{
			this.setGuitarName("Gibson");
			
		}
		if(choice.equals("2"))
		{
			this.setGuitarName("Fender Telecaster");
		}
		if(choice.equals("3"))
		{
			this.setGuitarName("Gibson Flying V");
		}
		
	}
	
	public void playSolo() {
		solobehav.playSolo();
	}

	public void setGuitarName(String guitarName) {
		this.guitarName = guitarName;
	}

	public String getGuitarName() {
		// TODO Auto-generated method stub
		return guitarName;
	}

}
